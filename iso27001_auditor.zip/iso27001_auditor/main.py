import json
import os
import sys
import math

try:
    from dotenv import load_dotenv
    from google import genai
    from openai import OpenAI
except ImportError:
    print("Please install required libraries by running:")
    print("python -m pip install openai python-dotenv google-genai")
    sys.exit(1)

# Load environment variables from .env
load_dotenv()

# Path to your JSON knowledge base
JSON_PATH = r"c:\Users\PC\Downloads\iso27001_metadata.json"
EMBEDDINGS_CACHE = "embeddings_cache.json"

def load_knowledge_base():
    try:
        with open(JSON_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Error: Could not find the file at {JSON_PATH}")
        sys.exit(1)
    except json.JSONDecodeError:
        print("Error: The file is not a valid JSON.")
        sys.exit(1)

def cosine_similarity(vec1, vec2):
    dot_product = sum(a * b for a, b in zip(vec1, vec2))
    norm_a = math.sqrt(sum(a * a for a in vec1))
    norm_b = math.sqrt(sum(b * b for b in vec2))
    return dot_product / (norm_a * norm_b) if norm_a and norm_b else 0.0

class SimpleRAG:
    """
    A basic Retrieval-Augmented Generation (RAG) implementation.
    It chunks text, generates vector embeddings, and retrieves relevant chunks via cosine similarity.
    """
    def __init__(self, client, embedding_model, is_gemini):
        self.client = client
        self.embedding_model = embedding_model
        self.is_gemini = is_gemini
        self.chunks = []
        self.embeddings = []
        
    def chunk_text(self, text, chunk_size=1000, overlap=100):
        chunks = []
        start = 0
        while start < len(text):
            end = start + chunk_size
            chunks.append(text[start:end])
            start += chunk_size - overlap
        return chunks

    def get_embeddings(self, texts):
        if self.is_gemini:
            response = self.client.models.embed_content(
                model=self.embedding_model,
                contents=texts
            )
            return [e.values for e in response.embeddings]
        else:
            response = self.client.embeddings.create(
                input=texts,
                model=self.embedding_model
            )
            return [data.embedding for data in response.data]

    def get_embedding(self, text):
        if self.is_gemini:
            response = self.client.models.embed_content(
                model=self.embedding_model,
                contents=text
            )
            return response.embeddings[0].values
        else:
            response = self.client.embeddings.create(
                input=text,
                model=self.embedding_model
            )
            return response.data[0].embedding

    def build_index(self, data):
        print("Building RAG Index (Chunking and Embedding)...")
        text_data = json.dumps(data, indent=2)
        self.chunks = self.chunk_text(text_data)
        
        if os.path.exists(EMBEDDINGS_CACHE):
            with open(EMBEDDINGS_CACHE, "r") as f:
                cached = json.load(f)
                if len(cached["chunks"]) == len(self.chunks):
                    print("Loaded embeddings from cache.")
                    self.embeddings = cached["embeddings"]
                    return

        print(f"Generating embeddings for {len(self.chunks)} chunks...")
        self.embeddings = self.get_embeddings(self.chunks)
        
        with open(EMBEDDINGS_CACHE, "w") as f:
            json.dump({"chunks": self.chunks, "embeddings": self.embeddings}, f)

    def retrieve(self, query, top_k=3):
        query_embedding = self.get_embedding(query)
        scored_chunks = []
        for chunk, emb in zip(self.chunks, self.embeddings):
            score = cosine_similarity(query_embedding, emb)
            scored_chunks.append((score, chunk))
        scored_chunks.sort(key=lambda x: x[0], reverse=True)
        return [chunk for score, chunk in scored_chunks[:top_k]]

def chat_completion(client, is_gemini, model_name, messages):
    if is_gemini:
        system_instruction = ""
        gemini_contents = []
        for m in messages:
            if m["role"] == "system":
                system_instruction += m["content"] + "\n"
            elif m["role"] == "user":
                gemini_contents.append({"role": "user", "parts": [{"text": m["content"]}]})
            elif m["role"] == "assistant":
                gemini_contents.append({"role": "model", "parts": [{"text": m["content"]}]})
        
        config = {"temperature": 0.7}
        if system_instruction:
            config["system_instruction"] = system_instruction
            
        response = client.models.generate_content(
            model=model_name,
            contents=gemini_contents,
            config=config
        )
        return response.text
    else:
        response = client.chat.completions.create(
            model=model_name,
            messages=messages,
            temperature=0.7
        )
        return response.choices[0].message.content

def main():
    print("=== ISO 27001 AI Auditor (with RAG) ===")
    
    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("API_KEY") or os.environ.get("OPENAI_API_KEY")
    if not api_key or api_key == "your_api_key_here":
        api_key = input("Please enter your API key: ").strip()

    is_gemini = api_key.startswith("AIza")
    if is_gemini:
        print("\n[+] Detected Gemini API Key! Using new Google GenAI SDK.")
        client = genai.Client(api_key=api_key)
        model_name = "gemini-2.5-flash"
        embedding_model = "gemini-embedding-2"
    else:
        print("\n[+] Using OpenAI API.")
        client = OpenAI(api_key=api_key)
        model_name = "gpt-4o-mini"
        embedding_model = "text-embedding-3-small"

    iso_data = load_knowledge_base()
    rag = SimpleRAG(client, embedding_model, is_gemini)
    rag.build_index(iso_data)

    print("\nConnecting to LLM...\n")
    print("-" * 50)
    
    system_prompt = """You are an expert ISO 27001 Lead Auditor and Consultant.
Your goal is to assess a client's ISMS compliance by asking them questions ONE AT A TIME.
When the user replies, I will provide you with relevant excerpts from the ISO 27001 standard retrieved via RAG (Retrieval-Augmented Generation).
Use those excerpts to determine if the user complies, and then ask the next logical question.

INSTRUCTIONS:
1. Start by introducing yourself briefly and asking the very first question to understand their organization's context.
2. ONLY ask ONE question at a time.
3. Keep your tone professional, conversational, and encouraging.
"""

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": "Hello. I am ready to begin the audit."}
    ]

    try:
        ai_reply = chat_completion(client, is_gemini, model_name, messages)
        print(f"AI Auditor: {ai_reply}")
        messages.append({"role": "assistant", "content": ai_reply})
        
        while True:
            print()
            user_input = input("You: ")
            
            if user_input.lower() in ['quit', 'exit', 'stop']:
                print("\nEnding the audit session. Goodbye!")
                break
                
            relevant_chunks = rag.retrieve(user_input, top_k=2)
            context_string = "\n\n".join(relevant_chunks)
            
            augmented_input = f"""User said: {user_input}
            
[Relevant ISO 27001 Context Retrieved via RAG]:
{context_string}

Based on the context and the user's answer, respond to the user and ask the next question."""

            messages.append({"role": "user", "content": augmented_input})
            
            ai_reply = chat_completion(client, is_gemini, model_name, messages)
            print(f"\nAI Auditor: {ai_reply}")
            messages.append({"role": "assistant", "content": ai_reply})
            
    except Exception as e:
        print(f"\nAn error occurred: {e}")

if __name__ == "__main__":
    main()
